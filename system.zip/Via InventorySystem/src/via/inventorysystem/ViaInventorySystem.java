
package via.inventorysystem;

/**
 *
 * @author 1styrGroupB
 */
public class ViaInventorySystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
          Loginform main= new Loginform();
        
          main.setVisible(true);
    }
    
}
